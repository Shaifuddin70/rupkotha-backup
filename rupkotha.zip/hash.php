<?php

echo password_hash("123123", PASSWORD_DEFAULT);
